# Emojione utility for iOS


### How to use

This utility provides a method to convert from shortname to unicode characters (natively supported from iOS 6).


### How to re-generate mapping

```
cd lib/ios/generator
npm install
node generate.js
```
