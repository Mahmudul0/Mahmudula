#### License

*  License: MIT
*  Complete Legal Terms: http://opensource.org/licenses/MIT